(function (ReactDOM, App) {
  ReactDOM.render(
    <App />,
    document.getElementById('app')
  )
})(ReactDOM, App)
